"""Maal regulatory-change MVP."""

