"""Maal regulatory-change MVP."""

